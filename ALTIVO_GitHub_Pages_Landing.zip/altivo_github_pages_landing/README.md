# ALTIVO OPTICS · landing provisional para GitHub Pages

## Qué incluye
- `index.html`: landing provisional, lista para GitHub Pages
- `assets/altivo-logo-white.png`: logo horizontal blanco de ALTIVO
- `CNAME`: configurado para `altivooptics.com`
- `.nojekyll`: evita procesamiento innecesario de Jekyll

## Publicación rápida
1. Crea un repositorio en GitHub. Si usas GitHub Free, el repositorio debe ser público.
2. Sube el contenido de esta carpeta al repositorio.
3. En GitHub ve a **Settings > Pages**.
4. En **Build and deployment**, elige **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/(root)`.
6. Guarda y espera el despliegue.

## Dominio personalizado en GitHub Pages
### Opción simple: usar el dominio raíz
Este paquete ya trae `CNAME` con:
`altivooptics.com`

En GitHub:
1. En **Settings > Pages**, confirma el campo **Custom domain**.
2. Activa **Enforce HTTPS** cuando aparezca disponible.

En Namecheap para el dominio raíz (`altivooptics.com`):
- configura los registros `A` y `AAAA` o un `ALIAS/ANAME` según soporte del proveedor.
- si quieres usar también `www`, agrega el subdominio después.

### Opción recomendada por GitHub: usar `www`
GitHub recomienda usar `www` porque es el subdominio más estable.
Si prefieres esa opción:
1. edita el archivo `CNAME` y reemplaza `altivooptics.com` por `www.altivooptics.com`
2. en Namecheap crea un `CNAME` de `www` apuntando a tu usuario de GitHub Pages
3. configura también el dominio raíz para que redirija al `www`

## Seguridad
- Verifica tu dominio en GitHub antes o al mismo tiempo que configuras Pages.
- No uses registros wildcard como `*`.

## Personalización rápida
- Texto principal en `index.html`: busca `Claridad en movimiento.`
- Correo de contacto: busca `altivooptics@gmail.com`
- Si luego quieres reemplazar esta landing por la web real, solo sustituyes `index.html`.
